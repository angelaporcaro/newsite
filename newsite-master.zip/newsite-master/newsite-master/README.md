# New Site
This is the new site repository. 

# Instructions on how to update site
1. Log into SSH
2. Navigate to /var/www/newsite
3. `sudo git pull`
